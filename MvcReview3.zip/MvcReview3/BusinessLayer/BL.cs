﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcReview3.DataAccessLayer;
using MvcReview3.Models;

namespace MvcReview3.BusinessLayer
{
    public class BL
    {
        public List<string> ScanExistingUsers()
        {
            List<string> ExistingUsers = new List<string>();
            DAL dal = new DAL();

            foreach (StudentInfo SI in dal.SInfo)
            {
                if (ExistingUsers.Find(x => x == SI.User) == null)
                {
                    ExistingUsers.Add(SI.User);
                }
                else
                {
                    continue;
                }
            }

            return ExistingUsers;

        }

        public void AddStudentInfo(StudentInfo SI)
        {
            DAL dal = new DAL();
            dal.SInfo.Add(SI);
            dal.SaveChanges();
        }

        public void AddStudentGrades(StudentGrades SG)
        {
            DAL dal = new DAL();
            dal.SGrades.Add(SG);
            dal.SaveChanges();
        }

        public StudentData ScanData(string UserName)
        {
            DAL dal = new DAL();
            StudentData SD = new StudentData();
            StudentInfo SI = new StudentInfo();            
            StudentGrades SG = new StudentGrades();
            

            if (dal.SInfo.ToList().Find(x => x.User == UserName) != null)
            {
                SI = dal.SInfo.ToList().Find(x => x.User == UserName);
                SD.Address = SI.Address;
                SD.Age = SI.Age;
                SD.Contact = SI.Contact;
            }
            else
            {
                SD.Address = "To be updated";
                SD.Age = 0;
                SD.Contact = "To be updated";
            }

            if (dal.SGrades.ToList().Find(x => x.User == UserName) != null)
            {
                SG = dal.SGrades.ToList().Find(x => x.User == UserName);
                SD.MATH101 = SG.MATH101;
                SD.NWEN301 = SG.NWEN301;
                SD.NWEN302 = SG.NWEN302;
                SD.SWEN202 = SG.SWEN202;
            }
            else
            {
                SD.MATH101 = 0;
                SD.NWEN301 = 0;
                SD.NWEN302 = 0;
                SD.SWEN202 = 0;
            }
            return SD;

        }

        public bool SIExists(string UserName)
        {
            DAL dal = new DAL();
            if (dal.SInfo.ToList().Find(x => x.User == UserName) == null)
            {
                return false;
            }
            else
            {
                return true;
            }

        }

        public void UpdateSI(StudentInfo SI, string UserName)
        {
            DAL dal = new DAL();
            if (SI.Address != "")
            {
                dal.SInfo.ToList().Find(x => x.User == UserName).Address = SI.Address;
            }
            if (SI.Age.ToString() != "")
            {
                dal.SInfo.ToList().Find(x => x.User == UserName).Age = SI.Age;
            }
            if (SI.Contact != "")
            {
                dal.SInfo.ToList().Find(x => x.User == UserName).Contact = SI.Contact;
            }

            dal.SaveChanges();
        }
    }
}