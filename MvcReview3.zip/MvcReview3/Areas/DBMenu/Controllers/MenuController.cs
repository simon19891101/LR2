﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcReview3.Areas.DBMenu.DataAccessLayer;
using MvcReview3.Areas.DBMenu.Models;

namespace MvcReview3.Areas.DBMenu.Controllers
{
    public class MenuController : Controller
    {
        // GET: DBMenu/Menu
        public ActionResult Index()
        {
            return View("Index");
        }

        public ActionResult GetMenu(String MenuName)
        {
            DAL dal = new DAL();
            MenuColumn MC = dal.AccessMenuColumn(MenuName);
            return PartialView("Menu", MC);
        }
    }
}