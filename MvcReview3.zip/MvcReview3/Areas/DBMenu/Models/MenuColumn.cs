﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcReview3.Areas.DBMenu.Models
{
    public class MenuColumn
    {
        public List<string> Column { set; get; } 
    }
}