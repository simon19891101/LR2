﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using MvcReview3.Areas.DBMenu.Models;

namespace MvcReview3.Areas.DBMenu.DataAccessLayer
{
    public class DAL
    {

        public MenuColumn AccessMenuColumn(string MenuName)
        {
            string connectionString = @"Data Source = (LocalDb)\MSSQLLocalDB; Integrated Security = true; Initial Catalog = MvcReview3";
            SqlConnection Cnt = new SqlConnection(connectionString);
            Cnt.Open();

            SqlCommand cmd = Cnt.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from MenuColumn where MenuName = " + "'"+ MenuName + "'";

            SqlDataReader reader = cmd.ExecuteReader();
            MenuColumn MC = new MenuColumn();
            MC.Column = new List<string>();

            while (reader.Read())
            {
                MC.Column.Add(reader["ColumnName"].ToString());
            }

            reader.Close();
            cmd.Dispose();
            Cnt.Close();
            Cnt.Dispose();
               

            return MC;


        }
        
    }
}