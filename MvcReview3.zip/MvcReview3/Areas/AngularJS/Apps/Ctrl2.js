﻿var Ctrl2 = function($scope,LocalListService)
{
    $scope.message = "I am a new controller";
    this.greeting = "Thanks for using Ctrl2";
    $scope.List = [];
    $scope.Countries = [
          "China",
          "India",
          "USA"
    ];
    $scope.myColor = 'red';

    $scope.ShowList = function()
    {
        /*
            $scope.List = [
            {Id:1, Name: 'GAGALi'},
            {Id:2, Name: 'Doudob'},
            {Id:3, Name: 'Ccana'}
            */
        
        LocalListService.List().success(function (data, status, headers, config) { $scope.List = data;});
        
    }
}