﻿var App2 = angular.module("App2", []);
App2.controller("App2Ctrl", ["$scope", function ($scope) {
    $scope.message = "I don't Like you";
}])