﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcReview3.Areas.AngularJS.Controllers
{
    public class TestController : Controller
    {
        // GET: AngularJS/Test
        public ActionResult Index()
        {
            return View("Index");
        }
    }
}