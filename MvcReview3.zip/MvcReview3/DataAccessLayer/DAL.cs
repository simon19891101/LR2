﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using MvcReview3.Models;

namespace MvcReview3.DataAccessLayer
{
    public class DAL:DbContext
    {
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<StudentInfo>().ToTable("SInfo");
            modelBuilder.Entity<StudentGrades>().ToTable("SGrades");
            base.OnModelCreating(modelBuilder);
        }

        public DbSet<StudentInfo> SInfo { set; get; }
        public DbSet<StudentGrades> SGrades { set; get; }
    }
}