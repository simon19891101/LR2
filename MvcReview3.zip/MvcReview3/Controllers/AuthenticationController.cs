﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace MvcReview3.Controllers
{
    public class AuthenticationController : Controller
    {
        // GET: Authentication
        public ActionResult LogIn()
        {
            return View("LogIn");
        }

        public ActionResult Rego()
        {
            return View("Rego");
        }

        public ActionResult DoRego(string UserName, string Password, string Btn)
        {
            if (Btn == "Submit")
            {
                if (Membership.GetUser(UserName) == null)
                {
                    Membership.CreateUser(UserName, Password);
                    GetRole(UserName);
                    ModelState.AddModelError("Rego", UserName + "Added!");
                    FormsAuthentication.SetAuthCookie(UserName, false);
                    return RedirectToAction("UserPanel", "MvcReview3");
                }
                else
                {
                    ModelState.AddModelError("Rego", "User alreadt exists");
                    return View("Rego");
                }
                
            }
            else
            {
                return RedirectToAction("Index", "MvcReview3");
            }
        }

        public ActionResult DoLogIn(string UserName, string Password, string Btn)
        {
            if (Btn == "Submit")
            {
                if (Membership.ValidateUser(UserName, Password))
                {
                    FormsAuthentication.SetAuthCookie(UserName, false);
                    return RedirectToAction("UserPanel", "MvcReview3");
                }
                else
                {
                    ModelState.AddModelError("LogIn", "User doesn't exist!");
                    return View("LogIn");
                }
            }
            else
            {
                return RedirectToAction("Index", "MvcReview3");
            }
        }

        public void GetRole(string Name)
        {
            if (Name == "Hang")
            {
                Roles.AddUserToRole(Name, "Admin");
            }
            else
            {
                Roles.AddUserToRole(Name, "Visitor");
            }

        }

        public ActionResult LogOut()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index","MvcReview3");
        }
    }
}