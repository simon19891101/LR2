﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcReview3.Models;
using MvcReview3.BusinessLayer;
using System.Web.Security;

namespace MvcReview3.Controllers
{
    [Authorize]
    public class MvcReview3Controller : Controller
    {
        // GET: MvcReview3
        [AllowAnonymous]
        public ActionResult Index()
        {
            return View("Index");
        }

        public ActionResult UserPanel()
        {
            return View("UserPanel");
        }

        public ActionResult Update()
        {
            return View("Update");
        }

        public ActionResult ExistingUsers()
        {
            BL bl = new BL();
            ExistingUsers eu = new ExistingUsers();
            eu.EU = bl.ScanExistingUsers();

            return PartialView("EixstingUsers", eu);
        }

        public ActionResult DoUpdate(StudentInfo SI, string Btn)
        {
            if (Btn == "Submit")
            {
                if (ModelState.IsValid)
                {                    
                    BL bl = new BL();
                    if (!bl.SIExists(User.Identity.Name))
                    {
                        SI.User = User.Identity.Name;
                        bl.AddStudentInfo(SI);
                        ModelState.AddModelError("DoAdd", "Added!");
                        
                    }
                    else
                    {
                        bl.UpdateSI(SI, User.Identity.Name);
                    }

                    return RedirectToAction("UserPanel");

                }
                else
                {
                    return View("Add");
                }
            }
            else
            {
                return RedirectToAction("UserPanel");
            }              
        }
        
        public ActionResult Scan()
        {
            BL bl = new BL();

            /*
            if (Roles.IsUserInRole(User.Identity.Name, "Admin"))
            {
                return new EmptyResult();
            }
            else
            {
                return PartialView("Scan", bl.ScanData(User.Identity.Name));
            }
            */

            return PartialView("Scan", bl.ScanData(User.Identity.Name));
        }


    }
}