﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcReview3.Models
{
    public class ExistingUsers
    {
        public List<string> EU { set; get; }
    }
}