﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MvcReview3.Models
{
    public class StudentInfo
    {
        [Key]
        [Required(ErrorMessage = "Id is required")]
        public int Id { set; get; }

        [Required(ErrorMessage = "Age is required")]
        [Range(0,100,ErrorMessage = "Age is out of range")]
        public int Age { set; get; }

        [Required(ErrorMessage = "Address is required")]
        public string Address { set; get; }

        [Required(ErrorMessage = "Contact is required")]
        [StringLength(10,ErrorMessage = "Too many digits for contact")]
        public string Contact { set; get; }

        public string User { set; get; }
    }
}