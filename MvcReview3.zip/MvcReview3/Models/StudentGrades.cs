﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MvcReview3.Models
{
    public class StudentGrades
    {
        [Key]
        public int Id { set; get; }

        [Range(0,100,ErrorMessage = "Grade out of range")]
        public int NWEN301 { set; get; }
        [Range(0, 100, ErrorMessage = "Grade out of range")]
        public int NWEN302 { set; get; }
        [Range(0, 100, ErrorMessage = "Grade out of range")]
        public int SWEN202 { set; get; }
        [Range(0, 100, ErrorMessage = "Grade out of range")]
        public int MATH101 { set; get; }

        public string User { set; get; }

    }
}