﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcReview3.Models;

namespace MvcReview3.Models
{
    public class StudentDataList
    {
        public List<StudentData> SDL { set; get; }
    }
}